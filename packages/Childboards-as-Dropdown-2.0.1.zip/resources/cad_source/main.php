<?php
/**
 * Childboards as Dropdown
 *
 * @file ./cad_source/main.php
 * @author Labradoodle-360
 * @copyright Matthew Kerle 2012
 *
 * @version 2.0.1
 */

if (!defined('SMF'))
	die('Hacking attempt...');

/*
	- Loads the custom language file.
	- Adds the JavaScript function to <head> via HTML Headers.
*/
function loadChildboards_as_Dropdown()
{

	// Load the language.
	loadLanguage('cad_language/main');

	// Throw the JavaScript function in the <head>.
	global $context;
	$context['html_headers'] .= "\n" . '
		<script type="text/javascript">
		//<![CDATA[
		function jsRedirect(input) {
			if (input.value == \'\') {
				// Analogy: Men\'s "Nothing Box".
			}
			else {
				window.location = smf_scripturl + \'?board=\' + input.value;
			}
		}
		//]]>
		</script>
	';

}